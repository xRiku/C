#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

typedef struct Carta{
    int Naipe;
    int Numero;
    int pont;
}Carta;

typedef struct TipoCelula* TipoApontador;

typedef struct TipoCelula{
    Carta Item;
    TipoApontador Prox;
}TipoCelula;

typedef struct TipoLista{
    TipoApontador Primeiro, Ultimo;
}TipoLista;

typedef struct Player{
    TipoLista Hand;
    TipoLista loot;
    int points;
}Player;

void BaralhoVazio(TipoLista *baralho);

int checkList(TipoLista *baralho, Carta carta);

void CriarBaralho(TipoLista *baralho);

void Imprime_Baralho(TipoLista *baralho);

void Kill_Baralho(TipoLista *baralho);

TipoLista Draw(TipoLista *baralho);

void Imprime_Carta(Carta item);

void Kill_Player(Player* Jog);

Carta Trunfo(TipoLista *baralho);

void Turn_Loot2(Player *P1, Player *P2, TipoApontador C1,TipoApontador C2, Carta trunfo);

void SetPlayer(Player *p);

int pontuacao(int numero);

void estrela(int n);

TipoCelula RetiraCarta(Player *P1, int card);