#include "funcoes_trabson.h"

void BaralhoVazio(TipoLista *baralho){
    baralho->Primeiro = baralho->Ultimo = NULL;
}

void CriarBaralho(TipoLista *baralho){
    srand(time(NULL));
    for (int i = 0; i < 40; i++){
        if (baralho->Primeiro == NULL){
            baralho->Primeiro = malloc(sizeof(TipoCelula));
            baralho->Primeiro->Item.Naipe = rand() % 4 + 1;
            baralho->Primeiro->Item.Numero = rand() % 10 + 1;
            baralho->Primeiro->Item.pont = pontuacao(baralho->Primeiro->Item.Numero);
            baralho->Ultimo = baralho->Primeiro;
            baralho->Ultimo->Prox = NULL;
        }
        else {
            Carta aux;
            baralho->Ultimo->Prox = malloc(sizeof(TipoCelula));
            do{
                aux.Naipe = rand() % 4 + 1;
                aux.Numero = rand() % 10 + 1;
            }while(checkList(baralho, aux));
            baralho->Ultimo->Prox->Item.Naipe = aux.Naipe;
            baralho->Ultimo->Prox->Item.Numero = aux.Numero;
            baralho->Ultimo->Item.pont = pontuacao(baralho->Ultimo->Prox->Item.Numero);
            baralho->Ultimo = baralho->Ultimo->Prox;
            baralho->Ultimo->Prox = NULL;
        }
    }
}

int checkList(TipoLista *baralho, Carta carta){
    TipoApontador p;
    for (p = baralho->Primeiro; p != NULL; p = p->Prox){
        if (p->Item.Naipe == carta.Naipe)
            if(p->Item.Numero == carta.Numero)
                return 1;
    }
    return 0;
}

TipoLista Draw(TipoLista *baralho){
    TipoLista hand;
    hand.Primeiro = baralho->Primeiro;
    for (int i = 0; i < 3; i++){
        hand.Ultimo = baralho->Primeiro;
        baralho->Primeiro = baralho->Primeiro->Prox;
    }
    hand.Ultimo->Prox = NULL;
    return hand;
}

Carta Trunfo(TipoLista *baralho){
    Carta carta;
    carta.Naipe = baralho->Primeiro->Item.Naipe;
    carta.Numero = baralho->Primeiro->Item.Numero;
    baralho->Primeiro = baralho->Primeiro->Prox;
    return carta;
}

void Imprime_Baralho(TipoLista *baralho){
    TipoApontador b;
    int i = 0;
    for (b = baralho->Primeiro; b != NULL; b = b->Prox){
        printf("Carta: %d\n", i+1);
        Imprime_Carta(b->Item);
        i++;
    }
}

void Kill_Baralho(TipoLista *baralho){
    TipoApontador b;
    for (b = baralho->Primeiro; b != NULL; b = b->Prox){
        free(b);
    }
}

void Kill_Player(Player* Jog){
    Kill_Baralho(&(Jog->Hand));
    Kill_Baralho(&(Jog->loot));
}

void Imprime_Carta(Carta item){
    printf("Naipe:  %d\n", item.Naipe);
    printf("Numero: %d\n", item.Numero);
}

void estrela(int n){
    for (int i = 0; i < n; i ++){
        putchar('*');
    }
    putchar('\n');
}

int pontuacao(int numero){
    switch(numero){
        case 1:
            return 11; 
            break;
        case 7:
            return 10;
            break;
        case 10:
            return 4;
            break;
        case 9:
            return 3;
            break;
        case 8:
            return 2;
            break;
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            return 0;
        default: 
            printf("ERRO.\nNumero fora do escopo entre 1 e 10\n");
            return 0;
    }
}

void Turn_Loot2(Player *P1, Player *P2, TipoApontador C1,TipoApontador C2, Carta trunfo){
    if(trunfo.Naipe == C1->Item.Naipe && trunfo.Naipe == C2->Item.Naipe){
        if(C1->Item.pont > C2->Item.pont){
            P1->points = P1->points + C1->Item.pont + C2->Item.pont;
            C1->Prox = P1->loot.Primeiro;
            P1->loot.Primeiro = C1;
            C2->Prox = P1->loot.Primeiro;
            P1->loot.Primeiro = C2;
            P1->loot.Primeiro->Prox = P1->loot.Primeiro;
        }else{
            P2->points = P2->points + C1->Item.pont + C2->Item.pont;
            C1->Prox = P2->loot.Primeiro;
            P2->loot.Primeiro = C1;
            C2->Prox = P2->loot.Primeiro;
            P2->loot.Primeiro = C2;
            P2->loot.Primeiro->Prox = P2->loot.Primeiro;
        }
    }else{
        if(trunfo.Naipe == C1->Item.Naipe){
            P1->points = P1->points + C1->Item.pont + C2->Item.pont;
            C1->Prox = P1->loot.Primeiro;
            P1->loot.Primeiro = C1;
            C2->Prox = P1->loot.Primeiro;
            P1->loot.Primeiro = C2;
            P1->loot.Primeiro->Prox = P1->loot.Primeiro;
        }else{
            if(trunfo.Naipe == C2->Item.Naipe){
                P2->points = P2->points + C1->Item.pont + C2->Item.pont;
                C1->Prox = P2->loot.Primeiro;
                P2->loot.Primeiro = C1;
                C2->Prox = P2->loot.Primeiro;
                P2->loot.Primeiro = C2;
                P2->loot.Primeiro->Prox = P2->loot.Primeiro;
            }else{
                if(C1->Item.Naipe == C2->Item.Naipe){
                    if(C1->Item.pont > C2->Item.pont){
                        P1->points = P1->points + C1->Item.pont + C2->Item.pont;
                        C1->Prox = P1->loot.Primeiro;
                        P1->loot.Primeiro = C1;
                        C2->Prox = P1->loot.Primeiro;
                        P1->loot.Primeiro = C2;
                        P1->loot.Primeiro->Prox = P1->loot.Primeiro;
                    }else{
                        P2->points = P2->points + C1->Item.pont + C2->Item.pont;
                        C1->Prox = P2->loot.Primeiro;
                        P2->loot.Primeiro = C1;
                        C2->Prox = P2->loot.Primeiro;
                        P2->loot.Primeiro = C2;
                        P2->loot.Primeiro->Prox = P2->loot.Primeiro;
                    }
                }else{
                    P1->points = P1->points + C1->Item.pont + C2->Item.pont;
                    C1->Prox = P1->loot.Primeiro;
                    P1->loot.Primeiro = C1;
                    C2->Prox = P1->loot.Primeiro;
                    P1->loot.Primeiro = C2;
                    P1->loot.Primeiro->Prox = P1->loot.Primeiro;
                }
            }
        }
    }
}

void SetPlayer(Player *p){
    BaralhoVazio(&p->Hand);
    BaralhoVazio(&p->loot);
    p->points = 0;
}

TipoCelula RetiraCarta(Player *P1, int card){
    int i;
    TipoApontador p, ant;
    switch(card){
        case 1: p = P1->Hand.Primeiro;
                P1->Hand.Primeiro = P1->Hand.Primeiro->Prox;
                p->Prox = NULL;
                return *p;
        case 2: p = P1->Hand.Primeiro->Prox;
                P1->Hand.Primeiro->Prox = P1->Hand.Ultimo;
                p->Prox = NULL;
                return *p;
        case 3: p = P1->Hand.Ultimo;
                ant = P1->Hand.Primeiro->Prox;
                ant->Prox = NULL;
                P1->Hand.Ultimo = ant;
                p->Prox = NULL;
                return *p;
        default:
            printf("ERRO.\n");
    }
}