#include "funcoes_trabson.h"

int main(){
    estrela(30);
    printf("\tB I S C A !\n");
    estrela(30);
    printf("Escolha o modo de jogo:\n1 - 2 Jogadores\n2 - 4 Jogadores\n");
    int opcao;
    do{
        scanf("%d", &opcao);
    }while(opcao != 1 && opcao != 2);
    printf("Modo de jogo: ");
    switch(opcao){
        case 1: printf("2 Jogadores\n");
            break;
        case 2: printf("4 Jogadores\n");
            break;
        default: puts("ERRO");
    }
    printf("Escolha a Dificuldade:\n1 - Muito Facil\n2 - Facil\n");
    do{
        scanf("%d", &opcao);
    }while(opcao != 1 && opcao != 2);
    printf("Dificuldade: ");
    switch(opcao){
        case 1: printf("Muito Facil\n");
            break;
        case 2: printf("Facil\n");
            break;
        default: puts("ERRO");
    }
    if (opcao == 1){
        // while(1){
        Player P1, P2;
        SetPlayer(&P1);
        SetPlayer(&P2);
        TipoLista baralho;
        BaralhoVazio(&baralho);
        CriarBaralho(&baralho);
        Imprime_Baralho(&baralho);
        P1.Hand = Draw(&baralho);
        P2.Hand = Draw(&baralho);
        Carta trunfo = Trunfo(&baralho);
        Imprime_Carta(trunfo);
        estrela(30);
        Imprime_Baralho(&P1.Hand);
        estrela(30);
        printf("SERECT YOUR CAR: ");
        int card;
        do{
            scanf("%d", &card);
        }while(card != 1 && card != 2 && card != 3);
        //PICK A CARD
        Turn_Loot2(&P1, &P2, C1, C2, Carta trunfo)
        Kill_Baralho(&baralho);
        Kill_Player(&P1);
        Kill_Player(&P2);
        // printf("Escolha sua Carta: ");
        // do{
        //     scanf("%d", &opcao);
        // }while(opcao != 1 && opcao != 2 && opcao != 3);
        // Turn_Loot2(Player *P1, Player *P2, Carta* C1, Carta* C2, Carta trunfo);
        // }
    }
    // Kill_List(&baralho);
}