#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
    int codigo;
    char *nome;
    float preco;
    int qtd;
} Produto;

typedef struct TipoCelula *TipoApontador;

typedef struct TipoCelula{
    Produto Item;
    TipoApontador Prox;
} TipoCelula;

typedef struct{
    TipoApontador Primeiro, Ultimo;
} TipoLista;

void FLVazia(TipoLista *Lista);

int Vazia(TipoLista Lista);

void Insere(Produto x, TipoLista *Lista);

void Retira(int codigo, TipoLista *l, Produto *x);

int Quantidade(TipoLista Lista);

void ImprimeLista(TipoLista Lista);

Produto criaProduto(int cod, char *nome, int qtd, float preco);

Produto maisBarato(TipoLista *lista);

void ImprimeProduto(Produto p);

TipoApontador BuscaCodigo(int codigo, TipoLista *l);

int EmStock(Produto x);

void Kill_List(TipoLista *l);