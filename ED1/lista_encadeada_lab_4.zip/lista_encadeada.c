#include "funcoes_lista_encadeada.h"

int main(int argc, char *argv[]){

  TipoLista lista;
  Produto item;

  FLVazia(&lista);
  item = criaProduto(1, "Sabonete", 10, 3.90);
  // ImprimeProduto(item);
  Insere(item, &lista);
  item = criaProduto(2, "Arroz", 20, 13.90);
  // ImprimeProduto(item);
  Insere(item, &lista);
  item = criaProduto(3, "Feijao", 1, 17.90);
  // ImprimeProduto(item);
  Insere(item, &lista);
  item = criaProduto(4, "Tomate", 0, 10);
  // ImprimeProduto(item);
  Insere(item, &lista);
  item = criaProduto(5, "Uva", 5, 8);
  // ImprimeProduto(item);
  Insere(item, &lista);
  // Insere(item, &lista);
  Retira(5, &lista, &item);
  ImprimeLista(lista);
  printf("[%d]\n", Quantidade(lista));
  // TipoApontador p = BuscaCodigo(3, &lista);
  // if (p != NULL)
  //   ImprimeProduto(p->Item);
  item = maisBarato(&lista);
  ImprimeProduto(item);
  Kill_List(&lista);
  return (0);
}