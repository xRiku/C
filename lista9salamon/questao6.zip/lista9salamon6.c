/*6) Faça um programa que apure o resultado de uma eleição que possua, 100 eleitores. Suponha
que existam 5 candidatos cujos códigos de identificação são: 1, 2, 3, 4, 5. Considere um arquivo
texto (denominado “votos.txt”) que contém, em cada linha, um determinado voto (um voto é
representado pelo código de identificação do candidato).
O programa deverá apresentar, como resultado, o código de identificação e a quantidade de
votos do candidato mais votado, o código de identificação e a quantidade de votos do candidato
menos votado e a quantidade de votos nulos (um voto nulo é um voto cujo código de
identificação é inválido).*/
#include <stdio.h>
#include <stdlib.h>
int maior(int *a, int n, int *qtd){
    int maiorr, i;
    maiorr = a[0];
    *qtd = 1;
    for ( i = 0; i < n; i++){
        if (a[i] > maiorr){
            maiorr = a[i]; 
            *qtd = i + 1;
        }
    }
    return maiorr;    
}
int menor(int *a, int n, int *qtd){
    int menor, i;
    menor = a[0];
    *qtd = 1;
    for ( i = 0; i < n; i++){
        if (a[i] < menor){
            menor = a[i]; 
            *qtd = i + 1;
        }
    }
    return menor;    
}

int main (){
    FILE *file = fopen("votos.txt", "r");
    if (file == NULL) {
        printf ("Erro na abertura de arquivo! Programa terminado...");
        exit (1);
    }
    int x, votos1, votos2, votos3, votos4, votos5, qtd, qtd2, pmaior, pmenor, nulo;
    votos1 = votos2 = votos3 = votos4 = votos5 = nulo = 0;
    while (!feof(file)){
        fscanf(file, "%d", &x);
        if (x == 1) {
            votos1++;
        }
        else{
            if (x == 2){
                votos2++;
            }
            else {
                if (x == 3){
                    votos3++;
                }
                else {
                    if (x == 4) {
                        votos4++;
                    }
                    else {
                        if (x == 5){
                            votos5++;
                        }
                        else  {
                            nulo++;
                        }
                    }
                }
            }
        }
    }
    fclose(file);
    int *vetor = malloc (sizeof(int)*5);
    vetor[0] = votos1;
    vetor[1] = votos2;
    vetor[2] = votos3;
    vetor[3] = votos4;
    vetor[4] = votos5;
    pmaior = maior(vetor, 5, &qtd);
    pmenor = menor(vetor, 5, &qtd2);
    free(vetor);
    printf("O candidato mais votado e: %d\nNumero de votos: %d\n", qtd, pmaior);
    printf("O candidato menos votado e: %d\nNumero de votos: %d\n", qtd2, pmenor);
    printf("Numero de votos nulos: %d\n", nulo);
    return 0;
}