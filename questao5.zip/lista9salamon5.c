/*5) Em uma cidade do interior, sabe-se que de janeiro a abril de 1990 (121 dias) não ocorreu
temperatura inferior a 15.5 graus centígrados nem superior a 39.7 graus centígrados. Considere
um arquivo texto (denominado “questao5.txt”) que contém todas as temperaturas ocorridas
nestes 121 dias (uma temperatura por linha). Faça um programa que calcule e apresente:
• a menor temperatura ocorrida;
• a maior temperatura ocorrida;
• a temperatura média;
• número de dias nos quais a temperatura foi inferior à temperatura média;
• número de dias nos quais a temperatura foi superior à temperatura média.*/

#include <stdio.h>
#include <stdlib.h>

int main (){
    FILE *file = fopen ("questao5.txt", "r");
    float x, maior, menor, soma = 0;
    int i, dia_maior, dia_menor;
    i = dia_maior = dia_menor = 0;
    if (file == NULL) {
        printf ("Erro na abertura de arquivo! Programa terminado...");
        exit (1);
    }
    while (!feof(file)){
        fscanf(file, "%f", &x);
        if (i == 0){
            maior = x;
            menor = x;
        }
        if (maior < x){
            maior = x;
        }
        if (menor > x){
            menor = x;
            printf("%d\n", i);
        }
        soma = x + soma;
        i++;
    }
    rewind(file);
    for(int j = 0; j < i; j++){
        fscanf(file, "%f", &x);
        if (x > soma/i){
            dia_maior++;
        }
        if (x < soma/i){
            dia_menor++;
        }
    }
    fclose(file);
    printf("A menor temperatura e: %.2f\n", menor);
    printf("A maior temperatura e: %.2f\n", maior);
    printf("A temperatura media e: %.2f\n", soma/i);
    printf("Numero de dias com a temp. maior que a media: %d\n", dia_maior);
    printf("Numero de dias com a temp. menor que a media: %d\n", dia_menor);
}